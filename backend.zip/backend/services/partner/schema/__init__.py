# Partner schema module
