# Partner service module
